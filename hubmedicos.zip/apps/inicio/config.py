# Configuration URLS
REGISTRO_REDIRECT_URL = 'registrarse/success/'
#INDEX_REDIRECT_URL = '/home'
LOGOUT_REDIRECT_URL = '/'
LOGIN_REDIRECT_URL_PACIENTES = "/paciente/perfilbasico/principal"
LOGIN_REDIRECT_URL_MEDICOS = "/home/"
