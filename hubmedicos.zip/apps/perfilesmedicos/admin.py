from django.contrib import admin
from .models import *
# Register your models here.
admin.site.register(Perfiles)
admin.site.register(Contactos)
admin.site.register(RedesSociales)
admin.site.register(PerfilProfesional)
admin.site.register(PerfilAcademico)
admin.site.register(PreguntasRespuestas)
admin.site.register(Pais)
admin.site.register(Dpto)
admin.site.register(Ciudad)
admin.site.register(Especialidad)
admin.site.register(Servicios)